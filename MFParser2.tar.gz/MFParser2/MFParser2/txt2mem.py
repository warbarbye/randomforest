import time

def prettyType(type_):
        return(type(type_).__name__)
def check_structure(lobject):
    types_u = list(map(lambda y: prettyType(y), lobject))
    if not 'list' in types_u:
        return('s')
    else:
        if lobject[0] == 'PRub.':
            return('p')
        else:
            return('c')
def key_val2dict(lobject):
    ldict = {}
    ldict[lobject[0]] = lobject[1]
    return(ldict)
def hkey_key_val2dict(lobject):
    ldict = {lobject[0] : {}}
    elems = lobject[1:]
    for elem in elems:
        ldict[lobject[0]][elem[0]] = elem[1]        
    return(ldict)
def prub2dict(lobject):
    ldict = {lobject[0] : {}}
    elems = lobject[1:]
    dict_list = []
    for elem in elems:
        dict_list.append( hkey_key_val2dict(elem))
    for it in range(0, len(dict_list)):
        ldict[lobject[0]][dict_list[it].keys()[0]] = {}
        for itt in range(0, len(dict_list[it].values()[0].keys())):
            ldict[lobject[0]][dict_list[it].keys()[0]][dict_list[it].values()[0].keys()[itt]] = dict_list[it].values()[0].values()[itt]
    return(ldict)
def gen_dict(lobject):
    code_txt = check_structure(lobject)
    if code_txt == 's':
        return(key_val2dict(lobject))
    elif code_txt == 'p':
        return(prub2dict(lobject))
    else:
        return(hkey_key_val2dict(lobject))
def section2dict(lobject):
    section_num = lobject[0]
    ldict = { section_num : {}}
    section_body = {}
    blank_body_list = {}
    sub_list = []
    for blank in lobject[1:]:
        if len(blank[0]) == 1:
            blank_number = blank[0][0]
        else:
            blank_number, blank_title = blank[0]
            blank_body_list[blank_number] = {}
        for key_val in blank[1:]:
            key_val_dict = gen_dict(key_val)
            blank_body_list[blank_number][key_val_dict.keys()[0]] = key_val_dict.values()[0]
        sub_list.append(blank_body_list)
    ldict[section_num] = blank_body_list
    return(section_num,ldict)
def body2dict(lobject):
    ldict = {}
    for section in lobject:
        section_num, section_dict = section2dict(section)
        ldict[section_num] = section_dict
    return(ldict)
def header2dict(lobject):
    header_list = lobject[0]
    ldict = dict.fromkeys(['poz', 'nazwa', 'krs', 'data_wpisu'])
    for i in range(0,len(header_list)):
         ldict[ldict.keys()[i]] = header_list[i]
    return(ldict)
def lframe2dframe(lobject):
    return({'header' : header2dict(lobject), 'body' : body2dict(lobject[1:])})



class Framef:
        def __init__(self, lframe):
                self.frame = lframe2dframe(lframe)
        def print_frame(self):
                print(self.frame)
        

class EcoEntity:
        def __init__(self, lframe):
                self.
                


frame_e2 = [['446930', 'RYSY ARCHITEKCI SPOLKA Z OGRANICZONA ODPOWIEDZIALNOSCIA', '0000705953', '01.12.2017'], ['01.12.2017', '1'], ['1', [['1', 'Dane podmiotu'], ['1', 'SPOLKA Z OGRANICZONA ODPOWIEDZIALNOSCIA'], ['3', 'RYSY ARCHITEKCI SPOLKA Z OGRANICZONA ODPOWIEDZIALNOSCIA'], ['5', 'NIE'], ['6', 'NIE']], [['2', 'Siedziba i adres podmiotu'], ['1', ['kraj', 'POLSKA'], ['wojewodztwo', 'MAZOWIECKIE'], ['powiat', 'PIASECZYNSKI'], ['gmina', 'LESZNOWOLA'], ['miejscowosc', 'MYSIADLO']], ['2', ['miejscowosc', 'MYSIADLO'], ['ulica', 'UL. TOPOLOWA'], ['nr domu', '2'], ['nr lokalu', '91'], ['kod pocztowy', '05-500'], ['poczta', 'MYSIADLO'], ['kraj', 'POLSKA']], ['3', ['Adres poczty elektronicznej', 'RS@RYSYARCHITEKCI.PL']], ['4', ['Adres strony internetowej', 'WWW.RYSYARCHITEKCI.PL']]], [['4', 'Informacje o umowie'], ['1', '23.11.2017 R.']], [['5', 'None'], ['1', 'CZAS NIEOZNACZONY'], ['3', 'WIEKSZA LICZBE UDZIALOW']], [['7', 'Dane wspolnikow'], ['1', ['1', 'SIERACZYMSKI'], ['2', 'RAFAL PIOTR'], ['3', '76012402011'], ['5', '91 UDZIALOW O LACZNEJ WARTOSCI 4.550 ZLOTYCH'], ['6', 'NIE']]], [['8', 'Kapital spolki'], ['1', '5000,00 ZL']]], ['2', [['1', 'Organ uprawniony do reprezentacji podmiotu'], ['1', ['1', 'ZARZAD'], ['2', 'DO SKLADANIA OSWIADCZEN W IMIENIU SPOLKI JEST UPOWAZNIONY KAZDY Z CZLONKOW ZARZADU SAMODZIELNIE.']], ['PRub.', ['1', ['1', 'SIERACZYNSKI'], ['2', 'RAFAL PIOTR'], ['3', '76012402011'], ['5', 'PREZES ZARZADU'], ['6', 'NIE']], ['2', ['1', 'STASZKIEWICZ'], ['2', 'MALGORZATA'], ['3', '76072200721'], ['5', 'CZLONEK ZARZADU'], ['6', 'NIE']]]]], ['3', [['1', 'Przedmiot dzialalnosci'], ['1', ['1', '71 11 Z DZIALALNOSC W ZAKRESIE ARCHITEKTURY']]]]]
fa = frame_first(frame_e2)
fa.print_frame()

 

