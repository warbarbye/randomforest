# -*- coding: utf-8 -*-
from pyparsing import *
#ParserElement.enablePackrat()
import regex
import pprint
from os.path import isfile, join


# alfabet
LITERY = 'AĄBCĆDEĘFGHIJKLŁMNŃOÓPQRSŚTUVWXYZŹŻ'
litery = 'aąbcćdeęfghijklłmnńoópqrsśtuvwxyzźż'


# funkcje
def joinTokens(tokens):
    return " ".join(tokens)


def joinTokens2(tokens):
    return "".join(tokens)


# gramatyka
SLOWO = Word(LITERY)
slowo = Word(litery + ',')
Slowo = Regex(r'[{0}][{1},]+'.format(LITERY, litery))
liczba = Word(nums)
kropka = Suppress(Literal('.'))
spacja = White(ws=' ', exact=1).suppress()
hiperklucz = (oneOf("wykreślić wpisać") + Suppress(":"))("hiperklucz")
numer = ((Word(nums)("numer") + kropka) | Keyword("--"))("numer")                                      # np '1.' lub '-'
tytul = (Slowo + ZeroOrMore(slowo + NotAny(":"))).setParseAction(joinTokens)("tytul").ignore("--")
dz = Keyword("Dz.").suppress() + numer
rub = Group(Keyword("Rub.").suppress() + numer + Optional(tytul, default='None'))("dane rubryki")
prub = Keyword("PRub.") + Optional(tytul).suppress()
stop = hiperklucz | prub | rub | dz | StringEnd()   # wykorzystywany w SkipTo()

# kody PKD (dz.3 rub.1)
kod = (Optional(Literal("--").suppress() + spacja) + OneOrMore(Word(nums, max=2) + spacja) +
       Optional(Word(LITERY, exact=1) + spacja)).suppress()

# klucze

klucz = ((WordStart() + Word(nums, max=2) + kropka + NotAny(StringEnd()) + WordEnd()) | (WordStart() + Word(nums, exact=1).suppress() + Keyword("--")))("klucz")              # np '1.'
nadklucz = (WordStart() + Word(nums, max=3) + NotAny(SLOWO ^ StringEnd()) + WordEnd() +
            FollowedBy(("(dla pozycji"+ Optional(spacja)+":") | klucz))("nadklucz")                    # np '1'
podklucz = (Optional("Adres") + OneOrMore(Word(litery, min=2)) + NotAny("/")).setParseAction(joinTokens)("podklucz")        # np 'klucz'

# ciala

# podklucz WARTOSC
podcialo = OneOrMore(
    Group(
        podklucz + spacja + SkipTo(spacja + podklucz, failOn=stop ^ klucz ^ (nadklucz + NotAny(klucz)))("wartosc")))("podcialo").ignore(podklucz + kropka)

# 1. WARTOSC lub 1. podcialo
cialo = OneOrMore(
    Group((klucz | (Suppress("--"))) + spacja +
          (podcialo | SkipTo(spacja + klucz + spacja+ NotAny(stop), failOn=stop ^ (nadklucz + "(dla pozyc"), ignore=nadklucz)("wartosc") +
           Suppress(Optional(klucz + stop)))))("cialo")


cialo2 = OneOrMore(
    Group(klucz + spacja + (podcialo | (Optional(Word(nums, max=3)) + SkipTo(spacja + klucz, failOn=(nadklucz | stop),
                                                                             ignore=(klucz + FollowedBy(stop)) ^ (oneOf(
                                                                                 "ART. UST. § PAR. PKT PPKT ,") + Word(
                                                                                 nums)))).setParseAction(joinTokens2)("wartosc"))))("cialo2")
# 1 WARTOSC lub 1 cialo2
nadcialo = OneOrMore(
    Group(nadklucz + spacja + (cialo2 | SkipTo(spacja + nadklucz, failOn=stop, ignore=klucz)("wartosc"))))("nadciało")

# naglowek

numer_poz = Word(nums)('pozycja') + kropka + Optional(spacja)
nazwa = SkipTo(Literal(". KRS") | Literal(".KRS"))('nazwa')
krs = Keyword("KRS").suppress() + Word(nums, exact=10)('KRS') + kropka
wpis = (OneOrMore(Word(litery)) + Literal(":")).suppress()
data = Combine(liczba + '.' + liczba + '.' + liczba + Optional(oneOf('r r. R.')))('data wpisu')
sygnatura = (Literal("[") + SkipTo("]") + Literal("]")).suppress()
naglowek = Group(
    numer_poz + nazwa + kropka + krs + SkipTo(":", include=True).suppress() + data + kropka + sygnatura)("naglowek")
ponaglowku = Group(Literal("W dniu").suppress() + data +
                   SkipTo("nr", include=True).suppress() +
                   liczba("numer wpisu") + SkipTo(":", include=True).suppress())("data i numer wpisu")

# rubryki

# PRub. ...
podrubryka = Group(prub + (cialo | nadcialo))("podrubryka")
# Rub. ...
rubryka = Group(rub + (cialo | nadcialo) + ZeroOrMore(podrubryka))("rubryka")
# Rub. 4. Informacje o umowie ...
rubryka_4 = Group(Literal("Rub.").suppress() + Group(numer + "Informacje o umowie") + Literal("1").suppress() + Group(
    numer + spacja + SkipTo(stop))("wartosc"))("rubryka")

# dzial

dzial = Group(dz + (OneOrMore(rubryka_4 | rubryka)))("dzial")

#dzial_3 = Group(dz + Literal("Rub.").suppress() + Group(Group("1" + kropka + "Przedmiot działalności") + Group(
#    Literal("1").suppress() + klucz + Optional(kod) + SkipTo(nadklucz | stop)) + Optional(Group(SkipTo(stop)))))(
#    "dzial 3")

# ramka

ramka = naglowek + ponaglowku + OneOrMore(dzial)


#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
# wpisy kolejne

#metadane (dla pozycji: ...)
podcialo2 = OneOrMore(
    Group(
        podklucz + spacja + SkipTo(spacja + podklucz, failOn=stop ^ klucz ^ ")" ^ nadklucz)("wartosc")))("podcialo").ignore(podklucz + kropka)

metacialo = OneOrMore(
    Group(klucz + spacja + (podcialo2 | SkipTo(spacja + klucz, failOn=stop ^ ")", ignore=nadklucz ^ ("("+SkipTo(")")))("wartosc"))) | podcialo2)("cialo")

meta = (Suppress("(dla pozycji" + Optional(spacja) + ": ") + Group(metacialo | SkipTo(")")) + Suppress(')'))("meta")

#hipercialo (wpisać/wykreślić)

nadcialo2 = OneOrMore(
    Group(nadklucz + spacja + Optional(meta) + (
                cialo2 | SkipTo(spacja + nadklucz, failOn=stop, ignore=klucz)("wartosc"))))("nadciało2")

nadcialo3 = OneOrMore(
    Group(nadklucz + spacja + NotAny(meta) + (
                cialo2 | SkipTo(spacja + nadklucz, failOn=stop, ignore=klucz)("wartosc"))))("nadciało3")

podrubryka3 = Group(prub + (cialo | nadcialo3))("podrubryka")

hipercialo = Group(hiperklucz + OneOrMore(Group((nadcialo2 | cialo) + ZeroOrMore(podrubryka3 | nadcialo3)))("cialo"))("hipercialo")

hipercialo2 = Group(Group(nadklucz + meta) + OneOrMore(hipercialo))("hipercialo2")

tytul2 = ((tytul | Suppress("-")) + Optional(Group(nadklucz + meta))("metadane"))("tytul").ignore("--")

#rubryki i podrubryki
rub2 = Group(Keyword("Rub.").suppress() + numer + spacja + Optional(tytul2, default='None'))("dane rubryki")
prub2 = Keyword("PRub.") + Optional(spacja + tytul2).suppress()
podrubryka2 = Group(prub2 + OneOrMore(hipercialo))("podrubryka")
rubryka2 = Group(rub2 +OneOrMore(podrubryka2 | hipercialo2 | hipercialo))("rubryka")
pusta_rubryka = Suppress(rub + FollowedBy(Literal("Rub.") | Literal("Dz.") | StringEnd()))

rubryka2_4 = Group(Literal("Rub.").suppress() + Group(numer + ("Informacje o" + oneOf("umowie statucie")).setParseAction(joinTokens)) + OneOrMore(Group(hiperklucz + Group(nadklucz + Group(klucz + spacja + Group(SkipTo(spacja + hiperklucz, failOn=stop))))))("wartosc"))("rubryka")

# dzial

dzial2 = Group(dz + OneOrMore(rubryka2_4 | rubryka2 | pusta_rubryka))("dzial")
#dzial2_3 = Group(dz + Literal("Rub.").suppress() + Group(Group("1" + kropka + "Przedmiot działalności") + OneOrMore(Group(hiperklucz + spacja + SkipTo(spacja + hiperklucz, failOn=stop))("rubryka")) + ZeroOrMore(rubryka2 | pusta_rubryka)))("dzial 3")
wykreslenie = Group(Keyword("WYKREŚLENIE WSZYSTKICH WPISÓW Z KRAJOWEGO REJESTRU SĄDOWEGO. WPIS NIE JEST PRAWOMOCNY.") |
                    Keyword("WYKREŚLENIE WSZYSTKICH WPISÓW Z REJESTRU PRZEDSIĘBIORCÓW.") |
                    Keyword("UCHYLENIE WYKREŚLENIA PODMIOTU Z KRAJOWEGO REJESTRU SĄDOWEGO."))

ramka2 = naglowek + ponaglowku + (OneOrMore(dzial2) | wykreslenie)


print(rubryka2.runTests("Rub. -- -- 1 (dla pozycji: -- 2012-12-01) wpisać: -- 2013-12-10"))#Rub. 2. Siedziba i adres podmiotu wykreślić: 2. miejscowość WARSZAWA ulica JUTRZENKI nr domu 177 kod pocztowy 02-231 poczta WARSZAWA kraj POLSKA wpisać: 2. miejscowość WARSZAWA ulica ALEJE JEROZOLIMSKIE nr domu 56 C kod pocztowy 00-803 poczta WARSZAWA kraj POLSKA Rub. 4. Informacje o umowie wpisać: 1 1. 17.11.2009 ROKU, REP. A NR 4471/2009, NOTARIUSZ IWONA OKOŁOTOWICZ, KANCELARIA NOTARIALNA W WARSZAWIE, AL.SOLIDARNOŚCI NR 75 LOK. 36, ZMIENIONO CAŁĄ DOTYCHCZASOWĄ TREŚĆ UMOWY W TEN SPOSÓB, ŻE NADANO JEJ NOWE BRZMIENIE. Rub. 7. Dane wspólników wykreślić: 1 1. KARWIK 2. BOGDAN ANDRZEJ 3. 77011111454 5. TAK 6. NIE 7. NIE 8. NIE 9. TAK 10. 1.000.000,00 ZŁ 11. 45.000,00 ZŁ 12. TAK PRub. 1 1. 45.000,00 ZŁ 2. TAK wpisać: 2 1. KARWIK 2. BOGDAN ANDRZEJ 3. 77011111454 5. TAK 6. NIE 7. NIE 8. NIE 9. NIE 3 1. GRZYBOWSKI 2. TOMASZ 3. 69061713496 5. TAK 6. NIE 7. NIE 8. NIE 9. TAK 10. CZTERDZIEŚCI PIĘĆ TYSIĘCY ZŁOTYCH 11. CZTERDZIEŚCI PIĘĆ TYSIĘCY ZŁOTYCH 12. NIE PRub. 1 1. CZTERDZIEŚCI PIĘĆ TYSIĘCY ZŁOTYCH 2. NIE Dz. 2. Rub. 1. Uprawnieni do reprezentowania spółki 1 (dla pozycji: 1. WSPÓLNICY REPREZENTUJĄCY SPÓŁKĘ) PRub. Dane wspólników reprezentujących spółkę wpisać: 1 1. KARWIK 2. BOGDAN ANDRZEJ 3. 77011111454 Rub. 3. Prokurenci wykreślić: 1 1. KARWIK 2. BOGDAN ANDRZEJ 3. 77011111454 4. PROKURA SAMOISTNA Dz. 3. Rub. 1. Przedmiot działalności wykreślić: 1 1. 74 11 Z DZIAŁALNOŚĆ PRAWNICZA wpisać: 2 1. 69 10 Z DZIAŁALNOŚĆ PRAWNICZA Rub. 2. Wzmianki o złożonych dokumentach wpisać: 1 1. data złożenia 26.11.2009 okres 09.05.2007 - 31.12.2007 1 1. data złożenia 26.11.2009 okres 01.01.2008 - 31.12.2008 1 3. 09.05.2007 - 31.12.2007 1 3. 01.01.2008 - 31.12.2008 ", parseAll=True).asDict())
# 204649. „MOBIUS” SPÓŁKA Z OGRANICZONĄ ODPOWIEDZIALNOŚCIĄ. KRS 0000333227. SĄD REJONOWY POZNAŃ-NOWE MIASTO I WILDA W POZNANIU, VIII WYDZIAŁ GOSPODARCZY KRAJOWEGO REJESTRU SĄDOWEGO, wpis do rejestru: 23.07.2009. [PO.VIII NS-REJ.KRS/10965/18/872] W dniu 22.05.2018 dokonano wpisu do rejestru KRS nr 13 następującej treści:  Dz. 1. Rub. 7. Dane wspólników 1 (dla pozycji: 1. SIKORSKA 2. MONIKA 3. 70101009288  Dz. 2. Rub. 1. Organ uprawniony do reprezentacji podmiotu 1 (dla pozycji: 1. ZARZĄD SPÓŁKI) PRub. Dane osób wchodzących w skład organu wykreślić: 1 1. SZYMAŃSKI 2. PRZEMYSŁAW GRZEGORZ 3. 70101004115 5. PREZES ZARZĄDU 6. NIE wpisać: 2 1. PLEWIŃSKI 2. JAKUB MACIEJ 3. 93050607495 5. PREZES ZARZĄDU 6. NIE
# 203448. COOPERVISION POLAND SPÓŁKA Z OGRANICZONĄ ODPOWIEDZIALNOŚCIĄ. KRS 0000464435. SĄD REJONOWY DLA M.ST. WARSZAWY W WARSZAWIE, XII WYDZIAŁ GOSPODARCZY KRAJOWEGO REJESTRU SĄDOWEGO, wpis do rejestru: 10.06.2013. [WA.XII NS-REJ.KRS/23877/18/114] W dniu 22.05.2018 dokonano wpisu do rejestru KRS nr 14 następującej treści:  Dz. 2. Rub. 1. Organ uprawniony do reprezentacji podmiotu 1 (dla pozycji: 1. ZARZĄD) PRub. Dane osób wchodzących w skład organu 1 (dla pozycji: 1. HARTY 2. MARK STEPHEN) wpisać: 3. 62022116851 2 (dla pozycji: 1. KAUFMAN 2. CAROL ROSE) 3. 49062916005 3 (dla pozycji: 1. TATAR 2. AKOS) 3. 68052214875 4 (dla pozycji: 1. RICUPATI 2. AGOSTINO) 3. 67011815052 5 (dla pozycji: 1. CHESHIRE 2. RICHARD MICHAEL) 3. 69071115114
# 202645. REHABILITANCI.PL SPÓŁKA Z OGRANICZONĄ ODPOWIEDZIALNOŚCIĄ SPÓŁKA KOMANDYTOWA. KRS 0000337804. SĄD REJONOWY DLA KRAKOWA-ŚRÓDMIEŚCIA W KRAKOWIE, XI WYDZIAŁ GOSPODARCZY KRAJOWEGO REJESTRU SĄDOWEGO, wpis do rejestru: 25.09.2009. [KR.XI NS-REJ.KRS/15433/18/957] W dniu 22.05.2018 dokonano wpisu do rejestru KRS nr 11 następującej treści:  Dz. 1. Rub. 1. Dane podmiotu wykreślić: 3. „REHABILITANCI.PL TARASIUK I GRUZIEL” SPÓŁKA KOMANDYTOWA wpisać: 3. REHABILITANCI.PL SPÓŁKA Z OGRANICZONĄ ODPOWIEDZIALNOŚCIĄ SPÓŁKA KOMANDYTOWA  Rub. 4. Informacje o umowie wpisać: 1 1. 28.03.2018 R., REP. A NR 6949/2018, ZASTĘPCA NOTARIALNY NINA MIZIOŁEK-GABRYŚ, ZASTĘPCA NOTARIUSZA WOJCIECHA ZARZYCKIEGO, KANCELARIA NOTARIALNA W KRAKOWIE, UL. MOSIĘŻNICZA 3 - UCHYLENIE CAŁEJ DOTYCHCZASOWEJ TREŚCI UMOWY SPÓŁKI I PRZYJĘCIE NOWEGO TEKSTU JEDNOLITEGO UMOWY SPÓŁKI.  Rub. 7. Dane wspólników wykreślić: 1 1. TARASIUK 2. PAWEŁ JERZY 3. 65071602597 5. TAK 6. NIE 7. NIE 8. NIE 9. NIE 2 1. GRUZIEL 2. TOMASZ 3. 71060409171 5. NIE 8. NIE 9. NIE 3 1. KURZYDŁO 2. WOJCIECH 3. 81052803810 5. NIE 8. NIE 9. TAK 10. 5000 ZŁ (PIĘĆ TYSIĘCY ZŁOTYCH) 11. 5000 ZŁ (PIĘĆ TYSIĘCY ZŁOTYCH) 12. NIE PRub. 1 1. 5000 ZŁ (PIĘĆ TYSIĘCY ZŁOTYCH) 2. NIE 4 (dla pozycji: 1. WOCH CZAJKOWSKA 2. MARTA HELENA 3. 80051907006) 10. 5.000,00 ZŁ (WSPÓŁWŁASNOŚĆ Z ANTONIM STANISŁAWEM CZAJKOWSKIM) wpisać: 10. 5.000,00 ZŁ. (WSPÓŁWŁASNOŚĆ Z ANTONIM STANISŁAWEM CZAJKOWSKIM) 5.000,00 ZŁ. wykreślić: 11. 5.000,00 ZŁ wpisać: 11. 5.000,00 ZŁ. (WSPÓŁWŁASNOŚĆ Z ANTONIM STANISŁAWEM CZAJKOWSKIM) 5.000,00 ZŁ. PRub. 1 1. 5.000,00 ZŁ (WSPOŁWŁASNOŚĆ Z ANTONIM STANISŁAWEM CZAJKOWSKIM 5.000,00 ZŁ. 2. NIE 5 1. TARASIUK 2. PAWEŁ 3. 65071602597 5. TAK 6. NIE 7. NIE 8. NIE 9. TAK 10. 5.000,00 ZŁ 11. 5.000,00 ZŁ 12. NIE PRub. 1 1. 5.000,00 ZŁ 2. NIE 6 1. REHABILITANCI. PL SPÓŁKA Z OGRANICZONĄ ODPOWIEDZIALNOŚCIĄ 3. 368609279 4. 0000701410 8. NIE 9. NIE 7 1. GRABOWSKI 2. JAKUB 3. 85070805333 5. TAK 6. NIE 7. NIE 8. NIE 9. TAK 10. 5.000,00 ZŁ 11. 5.000,00 ZŁ 12. NIE PRub. 1 1. 5.000,00 ZŁ 2. NIE  Dz. 2. Rub. 1. Uprawnieni do reprezentowania spółki 1 (dla pozycji: 1. WSPÓLNICY REPREZENTUJĄCY SPÓŁKĘ) wykreślić: 2. KAŻDY Z KOMPLEMENTARIUSZY SAMODZIELNIE wpisać: 2. KOMPLEMENTARIUSZ REPREZENTUJE SPÓŁKĘ SAMODZIELNIE. PRub. Dane wspólników reprezentujących spółkę wykreślić: 1 1. TARASIUK 2. PAWEŁ JERZY 3. 65071602597 2 1. GRUZIEL 2. TOMASZ 3. 71060409171 wpisać: 3 1. REHABILITANCI.PL SPÓŁKA Z OGRANICZONĄ ODPOWIEDZIALNOŚCIĄ 3. 368609279 4. 0000701410

monitor = (ramka2 | ramka)

from time import time
start = time()
#ParserElement.enablePackrat()
'''
with open("C:\\Users\\GTFH\\Documents\\pliki_dir\\pdf\\inne\\test2008\\txt_files\\filter_monitor_2008_128_clean.txt", "rt",
          encoding='utf-8') as file:
    tekst = file.readlines()
parsed = []
errors = 0
n = len(tekst)
for i in range(500):
    line = tekst[i]
    if len(line) != 1:
        print(i//2+1)
        try:
            monitor.parseString(line, parseAll=True)
        except ParseException as pe:
            errors += 1
            print('\x1b[1;31m' + pe.msg + '\x1b[0m')
            print("{e.line}".format(e=pe))
            print(" "*(pe.col-1) + "^")
print()
print("Bledy: {:d} ".format(errors))
end = time()
print("Czas: {:5.2f} s".format(end - start))


with open("C:\\Users\\GTFH\\Documents\\pliki_dir\\pdf\\inne\\test2018\\txt_files\\filter_monitor_2018_120_clean.txt", "rt",
          encoding='utf-8') as file:
    tekst = file.readlines()
errors = 0
for i in range(len(tekst)):
    line = tekst[i]
    if len(line) != 1:
        print(i//2+1)
        test = monitor.runTests(line, parseAll=True, printResults=False)
        if not test[0]:
            #print(test[1])
            monitor.runTests(line, parseAll=True)
            errors += 1
            #break

'''

def TXTparser(path):
    '''
    Parsuje wpisy do KRS z MSiG
    :param path: Sciezka do pliku txt
    :return: Lista zawierajaca sparsowane listy odpowiadajace wpisom
    '''
    assert(isfile(path))
    #wczytanie pliku linia po linii
    with open(path, "rt", encoding='utf-8') as file:
        tekst = file.readlines()
    parsed = []
    errors = 0
    n = len(tekst)
    for i in range(n):
        line = tekst[i]
        if len(line) != 1:
            print("{0}/{1}".format(i // 2 + 1, n // 2))
            #dodanie sparsowanej pozycji do listy
            try:
                parsed.append(monitor.parseString(line, parseAll=True).asList())
            except ParseException as pe:
                errors += 1
                print('\x1b[1;31m' + pe.msg + '\x1b[0m')
                print("{e.line}".format(e=pe))
                print(" " * (pe.col - 1) + "^")
    print()
    print("Bledy: {:d} ".format(errors))
    return parsed

#test1 = TXTparser("C:\\Users\\GTFH\\Documents\\pliki_dir\\pdf\\inne\\test2007\\txt_files\\filter_monitor_2007_252_clean.txt")

"""
import pickle

testy = open("C:\\Users\\GTFH\\Documents\\pliki_dir\\pdf\\testy\\txt_files\\monitor_2017_240_test.p", "wb")
pickle.dump(test1, testy, protocol=2)
testy.close()

from os import listdir
dir = "C:\\Users\\GTFH\\Documents\\pliki_dir\\pdf\\inne\\test2014\\txt_files\\"

for file in listdir(dir):
    TXTparser(join(dir,file))
end = time()
print("Czas: {:5.2f} s".format(end - start))

"""
