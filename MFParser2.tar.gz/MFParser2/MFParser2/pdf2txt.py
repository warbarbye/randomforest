# -*- coding: utf8 -*-
import re
import tempfile
import sys
import os
from os import listdir, makedirs
from os.path import join, isdir, exists
from tika import parser
import subprocess
from os.path import isfile
from os import remove
from time import time

start = time()
if len(sys.argv) not in [3, 4]:
    print(
        "usage: python pdf2txt.py source_dir pdf_version [v1 (07-12, 14) | v2 (13) | v3 (15-16) | v4(17-18) [-help] [-info]")
    exit()
elif "-help" in sys.argv:
    print(
        "Python script to transform unstructured KRS pdf file to semi-structured form. Source directory should contain only pdf files to transform to txt files and clean them. Pdf_version: v1 07-12 & 14, v2 13, v3 15-16, v5 17-18")
    exit()
elif "-info" in sys.argv:
    print("Authors: Wojciech Bogucki & Eryk Warchulski\nMeta: scirpt wokrs under python 2.7.x and 3.0")
    exit()
elif not (os.path.isdir(sys.argv[1])):
    print("ERROR: first argument must be directory.")
    print("usage: python pdf2txt.py source_dir pdf_version [v1 (07-12, 14) | v2 (13) | v3 (15-16) | v4(17-18) [-help]")
    exit()
elif sys.argv[2] not in ['v1', 'v2', 'v3', 'v4']:
    print("ERROR: invalid version.")
    print("usage: python pdf2txt.py source_dir pdf_version [v1 (07-12, 14) | v2 (13) | v3 (15-16) | v4(17-18) [-help]")
else:
    version = sys.argv[2]
    dirname_src = sys.argv[1]


def PDFReader(path, file_name, new_dir):
    '''
#    :param path: Ścieżka do pliku PDF
#    :param file_name: Nazwa pliku PDF
#    :param new_dir: Ścieżka do nowego katalogu
#    Funkcja tworzy plik txt w obecnym katalogu oraz tworzy podkatalog z oczyszczonymi plikiem txt
#    '''
    assert isfile(path)
    parsedPDF = parser.from_file(path)
    file_path = path.replace(".pdf", ".txt")
    with open(file_path, "w", encoding="utf-8") as file1:
        file1.write(parsedPDF["content"])
    command = 'C:\\Program Files\\R\\R-3.5.1\\bin\\Rscript'
    subprocess.call([command,
                     "clean_txt.R",
                     file_path, file_name, new_dir])
    remove(file_path)


def PDFParser(path_to_dir):
    '''
    :param path_to_dir: sciezka do folderu z plikami PDF
    Funkcja parsuje wszystkie pliki pdf do formatu txt oraz tworzy podfolder "txt_files" z oczyszczonymi plikami txt
    '''
    #   nazwy plikow
    files_names = listdir(path_to_dir)
    #   sciezki do plikow
    files = [join(path_to_dir, f) for f in files_names]
    #   tworzenie nowego podfolderu
    new_dir_name = "txt_files"
    new_dir = join(path_to_dir, new_dir_name)
    if not exists(new_dir):
        makedirs(new_dir)
    n = len(files_names)
    #    wykonanie funkcji PDFReader dla każdego pliku
    for i in range(n):
        if files_names[i].endswith('.pdf'):
            PDFReader(files[i], files_names[i], new_dir_name)
    return new_dir


txt_dir = PDFParser(dirname_src)
filters = {"v1": ['(?=(W P )).*?R\.\s?(?=|$)', '\s?- \s?[0-9]{1,3}\s?-\s?', 'O db.*?(_0 01\s?|00 1^(/)\s?)', '2. Kolejne\s?', '[0-9]{1,3}\s?–.*?R\.\s?', '1. Pierwsze.*SĄDOWEGO\s?', '~\s?', '——', 'INDEKS(?!.*INDEKS).*?]', '((\s?- )?\s?[0-9]{1,3}\s?(-\s?)?\s?)?(MONITOR SĄDOWY I GOSPODARCZY)'],
           "v2": ['O db.*?(_0 01\s?|00 1((/))?\s?)', '@ ', '(?=(W P )).*?R\.\s?(?=|$)', '\s?- \s?[0-9]{1,3}\s?-\s?', '2. Kolejne',
                  '~\s?', 'WPISY DO KRAJOWEGO REJESTRU SĄDOWEGO\s?'],
           "v3": ['X V\..*?R\.', '@ ', '~\s?', '——'],
           "v4": ['(?=(X V)).*?R\.\s?(?=|$)', '@ ', '~\s?', '——']

           }
regexs = {"v1": ['(?<= WPISY DO KRAJOWEGO REJESTRU SĄDOWEGO O).*', '^.*?(?= \- s\.|$)', '(?<=Poz\.).*?(?=Poz\.|$)'],
          "v2": ['(?<=1\. Pierwsze b\)).*', '^.*?(?= I N D E K S\s+K R S|$)', '(?<=Poz\.).*?(?=Poz\.|$)'],
          "v3": ['(?<= X V.).*', '^.*?(?= I N D E K S  K R S|$)', '(?<=Poz\.).*?(?=Poz\.|$)'],
          "v4": ['(?<= X V\.  W P I S Y  D O  K R A J O W E G O  R E J E S T R U  S Ą D O W E G O).*',
                 '^.*?(?= Cena brutto|$)', '(?<=Poz\.).*?(?=Poz\.|$    )']
          }
patterns_list = list(map(lambda pattern: re.compile(pattern), regexs[version]))
for elem in os.listdir(txt_dir):
    sample_text = open(os.path.join(txt_dir, elem), "r+", encoding="utf-8")
    output_text = open(txt_dir + "\\" + "filter_" + elem, "w+", encoding="utf-8")
    # output_text.truncate(0)
    temp_file = open("temp1.txt", "w+", encoding="utf-8")
    temp_file2 = open("temp2.txt", "w+", encoding="utf-8")
    temp_file2.write(sample_text.read())
    temp_file2.seek(0)
    for x in range(0, 3):
        temp_file.truncate(0)
        temp_file.write(temp_file2.read())
        temp_file.seek(0)
        output = patterns_list[x].findall(temp_file.read())
        temp_file.seek(0)
        temp_file2.truncate(0)
        for elem1 in output:
            temp_file2.write(elem1)
        temp_file2.seek(0)
        if x == len(patterns_list) - 1:
            temp_var = list(map(lambda x: re.sub('(?=[a-z]\)).*?(?=[0-9]{1,5}|$)', '', x), output))
            temp_var = list(map(lambda x: re.sub('  ', ' ', x), temp_var))
            temp_var = list(map(lambda x: re.sub('——', '-', x), temp_var))
            if version == "v1":
                change_letters = lambda y: y.group(0).upper()
                temp_var = list(
                    map(lambda x: re.sub('(?<=Dane podmiotu)\s?(1\.)\s?.*?(?=\d|$)', change_letters, x), temp_var))
            for filter_ in filters[version]:
                temp_var = list(map(lambda x: re.sub(filter_, '', x), temp_var))
                # temp_var = temp_var2
            # temp_var = list(map(lambda x: re.sub('(?=[a-z]\)).*?(?=[0-9]{1,5}|$)', '\n\n\g<0>\n', x), output))
            # temp_var2 = list(map(lambda x: re.sub('X V\..*?R\.', '', x), temp_var))
            for elem2 in temp_var:
                output_text.write("\n")
                output_text.write(elem2)
                output_text.write("\n")
    sample_text.close()
    remove(os.path.join(txt_dir, elem))
temp_file.close()
temp_file2.close()
remove("temp1.txt")
remove("temp2.txt")
output_text.close()

end = time()

print(end - start)
